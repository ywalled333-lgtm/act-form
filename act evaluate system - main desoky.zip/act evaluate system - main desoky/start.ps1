Write-Host "Starting ACT Performance Evaluation System..." -ForegroundColor Green
Write-Host ""
Write-Host "Opening in your default browser..." -ForegroundColor Yellow
Start-Process "index.html"
Write-Host ""
Write-Host "System is now running!" -ForegroundColor Green
Write-Host "You can close this window." -ForegroundColor Cyan
Read-Host "Press Enter to exit"
